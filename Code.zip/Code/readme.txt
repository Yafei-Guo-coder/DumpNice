01:Plot Chromosome density map.
02:Calculate IBS distance
03:Calculate population genetic diversity
04:Calculate the fixation index (FST)
05:Plot the genetic drift and genetic diversity of each population.
06:MDS analysis
07:Genotype PCA 
08:Extract geo-environmental climate variables
09:Population structure analysis
10:Xp-clr analysis
11:Xp-clr smooth
12:Xp-clr signal regions
13:Xp-clr with bayenv
14:Xp-clr haplotype
15:Xp-clr negative contral
16:RDA analysis
17:Sample location cluster analysis
18:Haplotype map
19:Plot the haplotype geographic distribution map.
20:Population structure visualization
21:Climate PCA
22:Candicate gene XP-CLR signal visualization
23:Candicate gene haplotype map
24:Candicate gene haplotype visualization
25:Candicate gene snpEff
26:Environmental GWAS
27:PPD gene analysis
28:Bayenv analysis
